<template>
    <div>
        Articles index !
    </div>
</template>

<script>
export default{
    name: 'ArticlesIndex'
}
</script>

<style>
    
</style>
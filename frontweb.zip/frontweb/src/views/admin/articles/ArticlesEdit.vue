<template>
    <div>
        Articles edit !
    </div>
</template>

<script>
export default{
    name: 'ArticlesEdit'
}
</script>

<style>
    
</style>
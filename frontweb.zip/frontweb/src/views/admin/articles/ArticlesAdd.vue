<template>
    <div>
        Articles add !
    </div>
</template>

<script>
export default{
    name: 'ArticlesAdd'
}
</script>

<style>
    
</style>
<template>
    <div class="admin">
        <AdminHeader />
        <div class="admin_contain">
            <div id="admin_side">
                <AdminNav />
            </div>
            <div id="admin_display">
                <router-view />
            </div>
        </div>
    </div>
</template>

<script>
import AdminHeader from '@/components/AdminHeader.vue'
import AdminNav from '@/components/AdminNav.vue'

export default{
    name: 'AdminLayout',
    components: {
    AdminHeader,
    AdminNav
}
}
</script>

<style>
    
</style>
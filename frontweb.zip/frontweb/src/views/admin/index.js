import AdminLayout from '@/views/admin/Layout.vue'
import Dashboard from '@/views/admin/Dashboard.vue'

import UsersIndex from '@/views/admin/users/UsersIndex.vue'
import UsersEdit from '@/views/admin/users/UsersEdit.vue'
import UsersAdd from '@/views/admin/users/UsersAdd.vue'

import ArticlesIndex from '@/views/admin/articles/ArticlesIndex.vue'
import ArticlesEdit from '@/views/admin/articles/ArticlesEdit.vue'

export{AdminLayout, Dashboard, UsersAdd, UsersEdit, UsersIndex, ArticlesEdit, ArticlesIndex}
<template>
    <div>
        Users index !
    </div>
</template>

<script>
export default{
    name: 'UsersIndex'
}
</script>

<style>
    
</style>
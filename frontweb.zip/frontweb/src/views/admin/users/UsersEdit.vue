<template>
    <div>
        Users Edit !
        <div> 
            {{ id }}
        </div>
    </div>
</template>

<script>
export default{
    name: 'UsersEdit',
    props: ['id']
}
</script>

<style>
    
</style>
<template>
    <div>
        <h1>Articles :</h1>
        <section>
            <div class="row">
                <div class="col" v-for="post in postsList" :key="post.id">
                    <div class="card">
                    <img src="https://picsum.photos/200/300" alt="">
                    <div class="card-body">
                        <h5 class="card-title">
                        {{post.title}}
                        </h5>
                        <button class="button1" v-on:click="this.$router.push('/')">
			                    Voir l'article ! 
		                </button>
                    </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>

export default{
    name: 'Article',

    data() {
          return {
              postsList: []
          }
        },
        mounted() {
          fetch('https://jsonplaceholder.typicode.com/posts')
              .then(response => response.json())
              .then(data => this.postsList.push(...data))
        }
}
</script>

<style>
* {
    box-sizing: border-box;
}

.row {
    display: flex;
    flex-wrap: wrap;
}

.col {
    width: calc(100% / 4);
    padding: 10px;
}

.card {
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}

.card img {
        width: 100%;
}

.card .card-id{
    padding: 1rem;
}  


.button1{
    padding: 1rem 3rem;
    text-align: center;
    font-size: 16px;
    text-transform: uppercase;
    cursor: pointer;
    background: #288eec;
    border: none;
    color: #fff;
    font-weight: bold;
    letter-spacing: 1px;
    border-radius: 25px;
}

.button1:hover{
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);;
}
        
</style>
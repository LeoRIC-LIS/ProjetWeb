import Home from '@/views/public/Home.vue'
import Article from '@/views/public/Article.vue'
import APropos from '@/views/public/APropos.vue'
import PublicLayout from '@/views/public/Layout.vue'

export {
    Home, Article, APropos, PublicLayout
}
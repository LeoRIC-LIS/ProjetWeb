<template>
    <div>
        A Propos
    </div>
</template>

<script>
export default{
    name: 'APropos'
}
</script>
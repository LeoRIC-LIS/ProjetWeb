<template>
    <div class="admin_header">
        HeaderAdmin ! 
    </div>
</template>

<script>
export default {
    name: 'AdminHeader'
}
</script>

<style>
    .admin_header {
        border-bottom: solid 1px black;
    }
</style>
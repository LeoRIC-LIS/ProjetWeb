<template>
    <div>
        <nav>
            <router-link to='/'>Accueil</router-link> |
            <router-link to='/article'>Article</router-link> |
            <router-link to='/apropos'>A Propos</router-link> |
            <router-link to='/admin/dashboard'>Admin</router-link>
        </nav>  
    </div>
</template>

<script>
export default{
    name: 'PublicNav'
}
</script>
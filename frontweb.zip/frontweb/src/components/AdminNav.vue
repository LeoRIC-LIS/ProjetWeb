<template>
    <div>
        <ul>
            <li><router-link to="/">Accueil</router-link></li>
            <li><router-link to="/admin/dashboard">Dashboard</router-link></li>
            <li><router-link to="/admin/users/index">Users index</router-link></li>
            <li><router-link to="/admin/users/edit/:id">Users ID</router-link></li>
        </ul>
    </div>
</template>

<script>
export default{
    name: 'AdminNav'
}
</script>
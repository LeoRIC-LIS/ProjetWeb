import { createRouter, createWebHistory } from 'vue-router'

import * as Public from '@/views/public'
import * as Admin from '@/views/admin'

import Login from '@/views/auth/Login.vue'
import { authGuard } from '@/_helpers/auth_guards'

const routes = [
  {
    path: '/',
    name: 'public',
    beforeEnter: authGuard,
    component: Public.PublicLayout,
    children: [
      {path: '/', name: 'Home', component: Public.Home},
      {path: '/article', name: 'Article',component: Public.Article},
      {path: '/apropos', name: 'APropos',component: Public.APropos}
    ]
  },

  {
    path: '/admin',
    name: 'admin',
    component: Admin.AdminLayout,
    children:[
      {path: 'dashboard', name: 'dashboard', component: Admin.Dashboard},
      {path: 'users/index', component: Admin.UsersIndex},
      {path: 'users/edit/:id', component: Admin.UsersEdit, props: true},
      {path: 'users/add', component: Admin.UsersAdd},

      {path: 'articles/index', component: Admin.ArticlesIndex},
      {path: 'articles/edit/:id', component: Admin.ArticlesEdit},
      {path: '/:pathMatch(.*)*', redirect: '/admin/dashboard'}
    ]
  },

  {
    path: '/login', name: 'Login', component: Login
  },
  
  {
    path: '/:pathMatch(.*)*', redirect: '/'
  }

]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

// Vérouillage de la partie admin (token)
router.beforeEach((to, from, next) => {
  if(to.matched[0].name == 'admin'){
    authGuard()
  }
  next()
})

export default router
